+++
description = "An example of a post without a sidebar"
date = "2017-12-25T00:00:00"
thumbnail = "images/pic08.jpg"
image = "images/pic01.jpg"
title = "No Sidebar"
slug = "no-sidebar"
author = "John Smith"
draft = false
disqusid = "4"
hidesidebar = true
+++
An example of a post without a sidebar.

```
+++
hidesidebar = true
+++
```