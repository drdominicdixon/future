+++
description = "An example of a blog post where comments are not allowed"
date = "2018-01-05T00:00:00"
thumbnail = "images/pic08.jpg"
image = "images/pic01.jpg"
title = "No Comments Allowed"
slug = "no-comments-allowed"
author = "John Smith"
draft = false
+++
This is an example of a blog post where comments are not allowed.