---
title: Contact
date: 2017-06-07T15:36:00+05:30
nodateline: true
noprevnext: true
disable_comments: true

---

# You may contact me through the nearest wormhole

This is where my great contact goes

