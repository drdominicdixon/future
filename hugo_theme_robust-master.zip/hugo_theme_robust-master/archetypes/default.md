+++
draft = true
thumbnail = ""
tags = []
categories = []
date = "{{ .Date }}"
title = "{{ replace .TranslationBaseName "-" " " | title }}"
description = ""
+++
