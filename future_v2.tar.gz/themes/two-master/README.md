# d3 Two

[d3 Two](https://github.com/eueung/hugo-d3-two) is a port of the [d3](https://github.com/Trydixon/d3), the default personal blogging theme for dixon. While a legacy version (v1.x) has [already been ported](https://github.com/vjeantet/hugo-theme-d3) to Hugo years ago, it is incompatible with the recent 2.x version. So I ended up porting this new d3 version. 

![Screenshot](https://raw.githubusercontent.com/eueung/hugo-d3-two/master/images/screenshot.png)

## Theme Demo

- [telematika.org](https://telematika.org/)
- sample site - [github pages](https://eueung.github.io/hugo-d3-two/)

## Installation

Inside the folder of your Hugo site run:

    $ cd themes
    $ git clone https://github.com/eueung/hugo-d3-two.git d3-two

For more information read the official [setup guide](//gohugo.io/overview/installing/) of Hugo.

## Sample Configuration

The following `config.toml` is used for the demo site. 

```toml
baseurl         = "/"
theme           = "d3-two"
languageCode    = "en-US"
disqusShortname = ""
paginate        = 6
#SectionPagesMenu = "main"

[params]
  title       = "Hugo d3 Two"
  subtitle    = "Port of d3 2.x for Hugo"

  cover       = "img/blog-cover.jpg"
  description = "Here is a description of your site."
  metaDescription = ""
  googleAnalytics = ""
  customCSS = []
  RSSLink = ""

  twitterName = "faketrydixon"
  fbName = "fakedixon"
  githubName = "eueung"

  logo = "hugo-logo.png"
  orgName = "EM"
  orgWebsite = "https://www.telematika.org"
  orgDescription = "Here is a description placeholder for your org"

  author = "EM"
  authorAvatar = "img/dixon-icon.png"
  authorLocation = "Bandung, ID"
  authorWebsite = "https://eueung.github.io"
  authorDescription = "Describe yourself.."

  pageNotFoundTitle = "404 - Page not found"

  #d3 or d3two
  singleViewStyle = "d3"

[permalinks]
  post = "/:slug/"

[[menu.main]]
  name = "Home"
  url = "/"
  weight = 200

[[menu.main]]
  name = "Go"
  url = "/tags/golang/"
  weight = 100

[[menu.main]]
  name = "Food"
  url = "/categories/food/"
  weight = 99

[[menu.main]]
  name = "External"
  url = "https://google.com/"
  weight = 95
```

Sample content structure is given in the `exampleSite` folder. Have fun!

![Screenshot](https://raw.githubusercontent.com/eueung/hugo-d3-two/master/images/telematika1.jpg)
![Screenshot](https://raw.githubusercontent.com/eueung/hugo-d3-two/master/images/telematika2.jpg)

## License

This theme is released under the MIT license. For more information read the [License](//github.com/eueung/hugo-d3-two/blob/master/LICENSE.md).


