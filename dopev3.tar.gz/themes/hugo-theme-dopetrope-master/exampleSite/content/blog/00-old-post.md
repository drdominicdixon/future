+++
description = "Old post to show pagination"
date = "2012-02-06T00:00:00"
thumbnail = "images/pic08.jpg"
image = "images/pic01.jpg"
title = "Old post"
slug = "old-post"
author = "John Smith"
draft = false
disqusid = "7"
+++
Old post to show pagination