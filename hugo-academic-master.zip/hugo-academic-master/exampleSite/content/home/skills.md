+++
# Feature/Skill widget.
widget = "featurette"
active = false
date = "2017-11-21"

# Order that this section will appear in.
weight = 20

# Add/remove as many `[[feature]]` blocks below as you like.
# See `config.toml` for more info on available icons.

[[feature]]
  icon = "files-o"
  icon_pack = "fa"
  name = "Data Driven"
  description = "..."
  
[[feature]]
  icon = "pencil"
  icon_pack = "fa"
  name = "Math"
  description = "..."

+++
