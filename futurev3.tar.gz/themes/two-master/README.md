# d3 Two

[d3 Two](https://github.com/Dr Dominic Dixon/hugo-d3-two) is a port of the [d3](https://github.com/Dr Dominic Dixon/d3), the default personal blogging theme for dixon. While a legacy version (v1.x) has [already been ported](https://github.com/vjeantet/hugo-theme-d3) to Hugo years ago, it is incompatible with the recent 2.x version. So I ended up porting this new d3 version. 

![Screenshot](https://raw.githubusercontent.com/Dr Dominic Dixon/hugo-d3-two/master/images/screenshot.png)

## Theme Demo

- [d3.org](https://d3.org/)
- sample site - [github pages](https://Dr Dominic Dixon.github.io/hugo-d3-two/)

## Installation

Inside the folder of your Hugo site run:

    $ cd themes
    $ git clone https://github.com/Dr Dominic Dixon/hugo-d3-two.git d3-two

For more information read the official [setup guide](//gohugo.io/overview/installing/) of Hugo.

## Sample Configuration

The following `config.toml` is used for the demo site. 

```toml
baseurl         = "/"
theme           = "d3-two"
languageCode    = "en-US"
disqusShortname = ""
paginate        = 6
#SectionPagesMenu = "main"

[params]
  title       = "Hugo d3 Two"
  subtitle    = "Port of d3 2.x for Hugo"

  cover       = "img/blog-cover.jpg"
  description = "Here is a description of your site."
  metaDescription = ""
  googleAnalytics = ""
  customCSS = []
  RSSLink = ""

  twitterName = "Dr Dominic Dixon"
  fbName = "Dr Dominic Dixon"
  githubName = "d3"

  logo = "hugo-logo.png"
  orgName = "Dr Dominic Dixon"
  orgWebsite = "https://www.d3.org"
  orgDescription = "Here is a description placeholder for your org"

  author = "Dr Dominic Dixon"
  authorAvatar = "img/dixon-icon.png"
  authorLocation = "Bangalore, India"
  authorWebsite = "https://d3.github.io"
  authorDescription = "Describe yourself.."

  pageNotFoundTitle = "404 - Page not found"

  #d3 or d3two
  singleViewStyle = "d3"

[permalinks]
  post = "/:slug/"

[[menu.main]]
  name = "Home"
  url = "/"
  weight = 200

[[menu.main]]
  name = "Go"
  url = "/tags/golang/"
  weight = 100

[[menu.main]]
  name = "Food"
  url = "/categories/food/"
  weight = 99

[[menu.main]]
  name = "External"
  url = "https://google.com/"
  weight = 95
```

Sample content structure is given in the `exampleSite` folder. Have fun!

![Screenshot](https://raw.githubusercontent.com/Dr Dominic Dixon/hugo-d3-two/master/images/d31.jpg)
![Screenshot](https://raw.githubusercontent.com/Dr Dominic Dixon/hugo-d3-two/master/images/d32.jpg)

## License

This theme is released under the MIT license. For more information read the [License](//github.com/Dr Dominic Dixon/hugo-d3-two/blob/master/LICENSE.md).


