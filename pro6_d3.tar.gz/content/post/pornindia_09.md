---
author: "NATION BUILDING & PUBLIC POLICY."
authordesc: "Dr Dominic Dixon has participated in extensive research studies in Psychology of Emotions and earned his doctorate in Counselling Psychology, and furthered research studies in Philosophy of Ethics at Oxford University, UK and Justice and Religion at Harvard University, US. Dominic F Dixon has also studied International Law and International Human Rights at Université Catholique de Louvain, Solving Public Policy Problems from University of California, Berkley."
date: 2018-08-24
linktitle: The Rape factor
next: /tutorials/github-pages-blog
prev: /tutorials/automated-deployments
title: The Rape factor
categories : ["Pornography"]
image: img/pexels-photo-1054422.jpeg
weight: 14
disqusid : "9"
authorAvatar: pr2.jpg
---


