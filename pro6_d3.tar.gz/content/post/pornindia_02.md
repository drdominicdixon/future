---
author: "NATION BUILDING & PUBLIC POLICY."
authordesc: "Dr Dominic Dixon has participated in extensive research studies in Psychology of Emotions and earned his doctorate in Counselling Psychology, and furthered research studies in Philosophy of Ethics at Oxford University, UK and Justice and Religion at Harvard University, US. Dominic F Dixon has also studied International Law and International Human Rights at Université Catholique de Louvain, Solving Public Policy Problems from University of California, Berkley."
date: 2018-08-18
linktitle: An epidemic of rape crimes in India
next: /category/An epidemic of rape crimes in India
prev: /tutorials/post/introduction/
title: An epidemic of rape crimes in India
categories : ["Pornography"]
weight: 3
image: img/pexels-photo-690729.jpeg
disqusid : "5"
authorAvatar: pr2.jpg
---



